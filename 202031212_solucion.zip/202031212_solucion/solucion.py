class Curso:
    def __init__(self, id, nombre, creditos, tiempodeestudio):
        self.id = id
        self.nombre = nombre
        self.creditos = creditos
        self.tiempodeestudio = tiempodeestudio

    def mostrar_ficha(self):
        print(f"ficha del curso {self.nombre} (ID: {self.id})")
        print(f"créditos: {self.creditos}")
        print(f"años de estudio: {self.tiempodeestudio}")
        print()

class Alumno:
    def __init__(self, id, nombre, email):
        self.id = id
        self.nombre = nombre
        self.email = email

    def mostrar_ficha(self):
        print(f"ficha del alumno {self.nombre} (ID: {self.id})")
        print(f"email: {self.email}")
        print()

class Matricula:
    def __init__(self, idmatricula, fechamatricula, idalumno, idcurso):
        self.idmatricula = idmatricula
        self.fechamatricula = fechamatricula
        self.idalumno = idalumno
        self.idcurso = idcurso

    def mostrar_datos(self):
        print(f"datos de matrícula (ID: {self.idmatricula})")
        print(f"fecha de matrícula: {self.fechamatricula}")
        print(f"ID del alumno: {self.idalumno}")
        print(f"ID del curso: {self.idcurso}")
        print()

class CentroEducativo:
    def __init__(self):
        self.matriculas = []

    def realizar_matricula(self, idmatricula, fechamatricula, idalumno, idcurso):
        matricula = Matricula(idmatricula, fechamatricula, idalumno, idcurso)
        self.matriculas.append(matricula)

    def mostrar_matriculas(self):
        print("matrículas realizadas en el centro:")
        for matricula in self.matriculas:
            matricula.mostrar_datos()


# Ejemplo de uso:
curso1 = Curso(1, "matemáticas", 4, 2)
curso2 = Curso(2, "historia", 3, 1)

alumno1 = Alumno(1, "Jaime García", "jaime@gmail.com")
alumno2 = Alumno(2, "Dario Penedo", "dario@gmail.com")

centro = CentroEducativo()

curso1.mostrar_ficha()
curso2.mostrar_ficha()

alumno1.mostrar_ficha()
alumno2.mostrar_ficha()

centro.realizar_matricula(1, "2023-01-01", alumno1.id, curso1.id)
centro.realizar_matricula(2, "2023-02-01", alumno2.id, curso1.id)
centro.realizar_matricula(3, "2023-02-15", alumno2.id, curso2.id)

centro.mostrar_matriculas()